export default function AppLoading() {
  return <div className="spinner-border spinner-border-sm" />;
}
